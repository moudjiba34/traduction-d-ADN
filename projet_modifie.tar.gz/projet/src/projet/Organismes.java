package projet;

import java.util.ArrayList;
import java.util.Random;

public abstract class Organismes implements Comparable<Object>{
private ArrayList<Organes> organes;// un organisme est constitue d'organes
public Organismes() {
	this.organes=new ArrayList<>();// reference 
	String sec = Adn.genererAdn();
	Random r=new Random(1000);// creation d'un variable de type random
	int Max=15;
	int Min=10;
	int n=Min + (int)(r.nextDouble()* (Max - Min+1)); // generere un nombre aleatoire entier
	for (int i = 0; i < n; i++) {
		organes.add(new Organes(sec));
	}
	}
	public ArrayList<Organes> getOrganes() {
		return organes;
	}
	public void setOrganes(ArrayList<Organes> organes) {
		this.organes = organes;
	}
	public abstract void respiration();
	@Override
		public int compareTo(Object m) {
			if(m.getClass().getSimpleName().equals("Animal"))
				return 1;
			else
			return 0;
		}
	public String getAdn() {
		return organes.get(0).getTissus().get(0).getCellules().get(0).getNoyau().getAdn().getBrin1();
	}
	}

