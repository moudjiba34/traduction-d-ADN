package projet;

import java.util.Random;

public class Adn {

	private String brin1, brin2;

	public Adn(String seq) {
		this.brin1 = seq;
		this.brin2 = brinComplementaire(brin1);
	}

	public String getBrin1() {
		return brin1;
	}

	public void setBrin1(String brin1) {
		this.brin1 = brin1;
	}

	public String getBrin2() {
		return brin2;
	}

	public void setBrin2(String brin2) {
		this.brin2 = brin2;
	}

	public static String brinComplementaire(String seq) {
		char[] tab = seq.toCharArray();
		for (int i = 0; i < seq.length(); i++) {
			if (tab[i] == 'A')
				tab[i] = 'T';
			else if (tab[i] == 'T')
				tab[i] = 'A';
			else if (tab[i] == 'C')
				tab[i] = 'G';
			else if (tab[i] == 'G')
				tab[i] = 'C';
		}
		return String.copyValueOf(tab);
	}

	public static String genererAdn()

	{
		String seq = "";
		Random rand = new Random();
		int min = 100, maxMoinsMin = 150 - min;
		int n = (int) (min + rand.nextDouble() * (maxMoinsMin));

		for (int i = 0; i < n; i++) {
			seq += "AGCT".charAt((int) (rand.nextDouble() * 4));
		}
		return seq;
	}

}



