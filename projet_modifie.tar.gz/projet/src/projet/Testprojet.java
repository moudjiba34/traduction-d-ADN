package projet;

import java.util.Iterator;
import java.util.Random;
import java.util.TreeSet;

public class Testprojet {

	public static void main(String[] args) {

		Animal a1 = new Animal();
		Animal a2 = new Animal();
		Animal a3 = new Animal();
		Animal a4 = new Animal();
		Animal a5 = new Animal();
		Animal a6 = new Animal();
		Animal a7 = new Animal();
		Animal a8 = new Animal();
		Animal a9 = new Animal();
		Animal a10 = new Animal();

		Vegetal V1 = new Vegetal();
		Vegetal V2 = new Vegetal();
		Vegetal V3 = new Vegetal();
		Vegetal V4 = new Vegetal();
		Vegetal V5 = new Vegetal();
		Vegetal V6 = new Vegetal();
		Vegetal V7 = new Vegetal();
		Vegetal V8 = new Vegetal();
		Vegetal V9 = new Vegetal();
		Vegetal V10 = new Vegetal();

		Vehicule P1 = new Vehicule();
		Vehicule P2 = new Vehicule();
		Vehicule P3 = new Vehicule();
		Vehicule P4 = new Vehicule();
		Vehicule P5 = new Vehicule();
		Vehicule P6 = new Vehicule();
		Vehicule P7 = new Vehicule();
		Vehicule P8 = new Vehicule();
		Vehicule P9 = new Vehicule();
		Vehicule P10 = new Vehicule();

		TreeSet<Organismes> t1 = new TreeSet<Organismes>();
		TreeSet<Mobilite> t2 = new TreeSet<Mobilite>();
		t1.add(a1);
		t1.add(a2);
		t1.add(a3);
		t1.add(a4);
		t1.add(a5);
		t1.add(a6);
		t1.add(a7);
		t1.add(a8);
		t1.add(a9);
		t1.add(a10);
		t1.add(V1);
		t1.add(V2);
		t1.add(V3);
		t1.add(V4);
		t1.add(V5);
		t1.add(V6);
		t1.add(V7);
		t1.add(V8);
		t1.add(V9);
		t1.add(V10);

		for (Organismes o : t1) {
			o.respiration();
		}

		t2.add(P1);
		t2.add(P2);
		t2.add(P3);
		t2.add(P4);
		t2.add(P5);
		t2.add(P6);
		t2.add(P7);
		t2.add(P8);
		t2.add(P9);
		t2.add(P10);
		t2.add(a1);
		t2.add(a2);
		t2.add(a3);
		t2.add(a4);
		t2.add(a5);
		t2.add(a6);
		t2.add(a7);
		t2.add(a8);
		t2.add(a9);
		t2.add(a10);

		for (Mobilite m : t2) {
			m.deplacement();
		}
		
	}
}