package projet;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Organes {
	List<Tissus> tissus1;
	public Organes (String sec) {
		this.tissus1 = new ArrayList<>();
		genererTissus(sec);
	}
	//private void genererTissus(String sec) {
		// TODO Auto-generated method stub
		
	//}
	public void genererTissus(String sec)
	  {
	 	
	 		Random rand = new Random(1000);
	 		int min= 15, moyen=20-min;
	 		int n = (int)(min +rand.nextDouble() *(moyen));
	 		for (int i = 0; i <n; i++) {
	 		
	 			tissus1.add(new Tissus());
	}
	}
	public ArrayList<Tissus> getTissus() {
		return (ArrayList<Tissus>) tissus1;
	}
	public void setTissus(ArrayList<Tissus> tissus) {
		this.tissus1 = tissus;
	}

}