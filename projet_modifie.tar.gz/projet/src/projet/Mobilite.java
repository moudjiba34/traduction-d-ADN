package projet;

public interface Mobilite {
	public void deplacement();
}
