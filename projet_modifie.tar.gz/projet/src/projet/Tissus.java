package projet;

import java.util.ArrayList;
import java.util.Random;

public class Tissus {
	 private ArrayList<Cellules> cellules;
	 public void generercellules(String sec) {
		 Random r=new Random();
		 this.cellules=new ArrayList<>();
		int Min=50;
		int Max = 75;
		int n=Min + (int)(r.nextDouble()* (Max - Min+1));
		System.out.println(n);
		for(int i=0;i<n;i++){
			cellules.add(new Cellules(sec));
			
		}
	}
	public ArrayList<Cellules> getCellules() {
		return cellules;
	}
	public void setCellules(ArrayList<Cellules> cellules) {
		this.cellules = cellules;
	}
}
