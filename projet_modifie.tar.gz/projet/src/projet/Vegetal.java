package projet;

public class Vegetal extends Organismes{
	
	private int longueur;
	
	public void respiration() {
		System.out.println("Respiration par les feuilles");
	}
	@Override
	public String toString() {
		return "Vegetal [longueur=" + longueur+ "]";
	}

	@Override
	public int compareTo(Object m) {
		if(m instanceof Organismes)
			return 1;
		else 
			return 0;
}
}
