package projet;

import java.util.ArrayList;

public class Noyau {
	private Adn adn;
	public Noyau(String sec) {
		this.adn=new Adn(sec);
	}
	public Adn getAdn() {
		return adn;
	}
	public void setAdn(Adn adn) {
		this.adn = adn;
	}
}
