package projet;

import java.util.ArrayList;

public class Utile {
	public static int getScore(String sec1, String sec2) {
		int match = 2;
		int mismatch = -2;
		int gap = -2;
		int[][] matrix = new int[sec2.length()][sec1.length()];

		matrix[0][0] = 0;
		for (int j = 1; j < sec1.length(); j++) {

			matrix[0][j] = matrix[0][j - 1] + gap;

		}
		for (int i = 1; i < sec2.length(); i++) {

			matrix[i][0] = matrix[i - 1][0] + gap;
		}
		for (int i = 1; i < sec2.length(); i++) {
			for (int j = 1; j < sec1.length(); j++) {

				int sub = (sec2.charAt(i - 1) == sec1.charAt(j - 1)) ? match : gap;
				matrix[i][j] = Math.max(matrix[i - 1][j - 1] + sub, matrix[i - 1][j] + gap);
				matrix[i][j] = Math.max(matrix[i][j], matrix[i][j - 1] + gap);

			}
		}

		return matrix[sec2.length()-1][sec1.length()-1];
		
	}
	public static double[][] getDistanceMatrix(ArrayList <Organismes> list)
	{
	   double[][] d=new double[10][10];
	   for ( int i=0;i<list.size();i++) {
		   String seq1 = list.get(i).getAdn();
		   for ( int j=0;j<list.size();j++){
			   String seq2 = list.get(j).getAdn();
			   if(i==j){
				   d[i][j] = 0;
			   }else   
			   {
				   d[i][j] = (double)1/getScore(seq1, seq2);			
			   }
		} 
		
	}
	   return d;
	}
}



