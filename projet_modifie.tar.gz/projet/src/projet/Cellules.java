package projet;

//import java.util.ArrayList;

public class Cellules {
	 private Noyau noyau;

	public Noyau getNoyau() {
		return noyau;
	}

	public void setNoyau(Noyau noyau) {
		this.noyau = noyau;
	}
	 public Cellules(String seq) {
			this.noyau = new Noyau(seq);
	

}
}
