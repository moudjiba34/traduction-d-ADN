package projet;

class Animal extends Organismes implements Mobilite  {

	public void respiration() {
		System.out.println("Respiration par les narines");
	}

	public void deplacement() {
		System.out.println("l'animal se deplace ");
		// TODO Auto-generated method stub
		
	}

	@Override
	public int compareTo(Object m) {
		if(m instanceof Organismes || m instanceof Mobilite)
			return 1;
		else 
			return 0;
		
	}
	

}
