package projet;

public class Vehicule implements Mobilite, Comparable<Object> {

	public void deplacement() {
		System.out.println("sa bouge");
		
		
	}

	@Override
	public int compareTo(Object m) {
		if(m instanceof Animal || m instanceof Mobilite)
			return 1;
		else 
			return 0;
	}

	
	}
	
	


